-- 1. Selection: Select all books priced above 5000
σ Price > 5000 (book)

-- 2. Selection: Select all users with "gmail.com" in their email
σ email LIKE '%gmail.com' (users)

-- 3. Projection: Display only book titles and their authors
π Title, Author (book)

-- 4. Projection: Display user names and their email addresses
π name, email (users)

-- 5. Union: Combine all orders placed by 'muhammad khan' with orders from 'Islamabad'
(σ full_name = 'muhammad khan' (`order`)) ∪ (σ address LIKE '%Islamabad%' (`order`))

-- 6. Intersection: Find common books between "Fantasy" and "Science Fiction" genres
(σ Genre = 'Fantasy' (book)) ∩ (σ Genre = 'Science Fiction' (book))

-- 7. Difference: Find books that are in stock but not out of stock
book − (σ Stock_Quantity = 0 (book))

-- 8. Cartesian Product: Pair each book with all users
book × users

-- 9. Join: Display book titles with their ordered quantities
book ⨝ book.Title = order_items.book_name

-- 10. Theta Join: Display books where the price is higher than 1000 and quantity ordered is greater than 5
book ⨝ book.Price > 1000 AND order_items.quantity > 5

-- 11. Division: Find users who ordered every book in the "Fantasy" genre
π email (order_items) ÷ π Title (σ Genre = 'Fantasy' (book))

-- 12. Group By: Count the number of books in each genre
γ Genre, COUNT(Title) → TotalBooks (book)

-- 13. Aggregation (SUM): Find the total revenue from all orders
γ SUM(total_price) → TotalRevenue (order_items)

-- 14. Aggregation (AVG): Find the average price of books
γ AVG(Price) → AveragePrice (book)

-- 15. Aggregation (MAX): Find the book with the maximum price
γ MAX(Price) → MaxPrice (book)

-- 16. Aggregation (MIN): Find the book with the minimum stock quantity
γ MIN(Stock_Quantity) → MinStock (book)

-- 17. Renaming: Rename the `book` table to `b` for simplicity
ρ b (book)

-- 18. Selection with Logical AND: Select books priced above 5000 and in stock
σ Price > 5000 AND Stock_Quantity > 0 (book)

-- 19. Set Difference: Find books that are in the "Cooking" genre but not priced above 3000
(σ Genre = 'Cooking' (book)) − (σ Price > 3000 (book))

-- 20. Join with Selection and Projection: Find user names and emails who ordered books priced above 5000
π name, email (users ⨝ users.email = `order`.email ⨝ `order`.order_id = order_items.order_id ⨝ order_items.book_name = book.Title ∧ book.Price > 5000)
